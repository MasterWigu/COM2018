#!/bin/bash  

./run.sh *.diy