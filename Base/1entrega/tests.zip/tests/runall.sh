#!/bin/bash  

./run.sh *.in